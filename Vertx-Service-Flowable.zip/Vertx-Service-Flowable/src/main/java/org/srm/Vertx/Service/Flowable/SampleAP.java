package org.srm.Vertx.Service.Flowable;

public class SampleAP {

	public SampleAP() {
		super();
	}
	
	
	public boolean getData() {
		return true;
	}
}
