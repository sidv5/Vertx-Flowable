package org.srm.Vertx.Service.Flowable;

public class FlowableAP  {
	/*public FlowableAP() {
		super();
	}
	public void eventBusAccess() {
		try {
			vertx.eventBus().send("service.validate", "sid", reply -> {
				System.out.println("service reply : " + reply.result());
			});
		} catch (Exception e) {
			e.printStackTrace();
			}
		
	}*/
}
