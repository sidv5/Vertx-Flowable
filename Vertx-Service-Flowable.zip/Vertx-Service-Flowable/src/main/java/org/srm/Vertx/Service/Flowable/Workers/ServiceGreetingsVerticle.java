package org.srm.Vertx.Service.Flowable.Workers;


import io.vertx.core.Vertx;

public class ServiceGreetingsVerticle {

}
